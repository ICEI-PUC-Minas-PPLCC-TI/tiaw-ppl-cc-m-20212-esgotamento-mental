var db_diario_inicial = {
    "data": [
        {
            "id": 1,
            "nome": "Café da manhã",
            "inicio": "06:30",
            "fim": "07:00",
        },
        {
            "id": 2,
            "nome": "Academia",
            "inicio": "07:00",
            "fim": "08:30",
        },
        {
            "id": 3,
            "nome": "Aulas",
            "inicio": "08:30",
            "fim": "12:30",
        },
        {
            "id": 4,
            "nome": "Almoço/Descanso",
            "inicio": "12:30",
            "fim": "14:30",
        },
        {
            "id": 5,
            "nome": "Treino",
            "inicio": "14:30",
            "fim": "17:30",
        },
        {
            "id": 6,
            "nome": "Estudo",
            "inicio": "17:30",
            "fim": "19:00",
        },
        {
            "id": 7,
            "nome": "Lazer",
            "inicio": "19:00",
            "fim": "00:00",
        },
    ]
}

var db = JSON.parse(localStorage.getItem('db_atividade'));
if (!db) {
    db = db_diario_inicial
};

function displayMessage(msg) {
    $('#msg').html('<div class="alert alert-warning">' + msg + '</div>');
}

function insertAtividade(atividade) {
    let novoId = 1;
    if (db.data.length != 0) 
      novoId = db.data[db.data.length - 1].id + 1;
    let novoAtividade = {
        "id": novoId,
        "nome": atividade.nome,
        "fim" : atividade.fim,
        "inicio": atividade.inicio,
    };

    db.data.push(novoAtividade);
    displayMessage("Atividade inserida com sucesso");

    localStorage.setItem('db_atividade', JSON.stringify(db));
}

function updateAtividade(id, atividade) {
    let index = db.data.map(obj => obj.id).indexOf(id);

    db.data[index].nome = atividade.nome,
    db.data[index].inicio = atividade.inicio
    db.data[index].fim = atividade.fim,

    displayMessage("Atividade alterada com sucesso");

    localStorage.setItem('db_atividade', JSON.stringify(db));
}

function deleteAtividade(id) {
    db.data = db.data.filter(function (element) { return element.id != id });

    displayMessage("Atividade removida com sucesso");

    localStorage.setItem('db_atividade', JSON.stringify(db));
}